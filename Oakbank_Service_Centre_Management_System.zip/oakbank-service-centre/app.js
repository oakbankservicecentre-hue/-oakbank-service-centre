const SUPABASE_URL = "https://gwzfrsixcdsyczbpmfqq.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_rC6FAks-NitzyqHgdh8z_w_8KfdZVqb";
const db = supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);

const loginView = document.getElementById("loginView");
const dashboardView = document.getElementById("dashboardView");
const logoutBtn = document.getElementById("logoutBtn");
const loginForm = document.getElementById("loginForm");
const loginMsg = document.getElementById("loginMsg");
const statusEl = document.getElementById("status");
const sectionPanel = document.getElementById("sectionPanel");

function showDashboard(session) {
  loginView.classList.add("hidden");
  dashboardView.classList.remove("hidden");
  logoutBtn.classList.remove("hidden");
  statusEl.textContent = session ? "Connected to Supabase ✓" : "Not signed in";
}

function showLogin() {
  loginView.classList.remove("hidden");
  dashboardView.classList.add("hidden");
  logoutBtn.classList.add("hidden");
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginMsg.textContent = "Signing in…";
  const { error } = await db.auth.signInWithPassword({
    email: document.getElementById("email").value,
    password: document.getElementById("password").value
  });
  if (error) loginMsg.textContent = error.message;
  else loginMsg.textContent = "";
});

logoutBtn.addEventListener("click", async () => {
  await db.auth.signOut();
  showLogin();
});

document.querySelectorAll(".tile").forEach(btn => {
  btn.addEventListener("click", async () => {
    const section = btn.dataset.section;
    sectionPanel.classList.remove("hidden");
    sectionPanel.innerHTML = `<h3>${btn.innerText.replace(/\n/g," ")}</h3><p class="muted">This section is ready for the next build step.</p>`;
    if (section === "customers") {
      const { data, error } = await db.from("customers").select("name,phone").order("created_at",{ascending:false}).limit(10);
      if (error) sectionPanel.innerHTML += `<p>${error.message}</p>`;
      else sectionPanel.innerHTML += data.length ? `<ul class="list">${data.map(x=>`<li><b>${escapeHtml(x.name)}</b><br><span class="muted">${escapeHtml(x.phone||"No phone")}</span></li>`).join("")}</ul>` : "<p>No customers yet.</p>";
    }
  });
});

function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

(async () => {
  const { data: { session } } = await db.auth.getSession();
  if (session) showDashboard(session);
  else showLogin();

  db.auth.onAuthStateChange((_event, session) => session ? showDashboard(session) : showLogin());
})();
