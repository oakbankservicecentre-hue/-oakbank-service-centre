# Oakbank Service Centre — Mobile Management System

## Supabase
The app is configured for the Supabase project:
https://gwzfrsixcdsyczbpmfqq.supabase.co

The browser uses the Supabase publishable key. Do not put an `sb_secret_...` key in this project.

## First login
In Supabase Dashboard:
Authentication → Users → Add user

Create the manager's email/password, then use those credentials in the app.

## Run locally
Because browsers can restrict local files, serve this folder from a small local web server. For example, with Python:

python3 -m http.server 8080

Then open:
http://localhost:8080

## Next build
The dashboard shell is ready. The next step is to add full CRUD screens for customers, vehicles, jobs, parts, payments, photos, and weekend reports.
